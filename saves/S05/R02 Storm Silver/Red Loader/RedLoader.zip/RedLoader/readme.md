To use in Desmume

    Tools > Lua Scripting > New Lua Script Window...

    Click Browse

    Load RedLoader.lua from this archive.

If Desmume complains that lua51.dll is missing, one has been provided for you. It may require the x86 version of Desmume to run.
To use, copy lua51.dll and lua5.1.dll to the Desmume folder.