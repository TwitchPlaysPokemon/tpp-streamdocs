Full party teams plus party xorpad (for verification, save2 parties are at 0x98600 (0x9869c with psave heaer)) are in Party Mons.
"Important" pokemon that don't appear in any of the parties can be found in "Important Boxed Mons."
Other pokemon extractable from the saves can be found in "Miscellaneous."

For ease of verification, Party members are stored as .ek6 files, and Boxed mons are stored as .pk6 files.

The actual powersaves dumps are located in the "Saves" folder.

NOTE: There are technically more pokemon recoverable by using known plaintext in box 1 to get some more pokemon out of the post-wondertrading safe file's box 1, but given none of those pokemon were caught by arty I didn't bother to retrieve them.