USAGE:

Apply to a V1.0 Pok�mon Ruby rom. The vanilla patch has pink blood on standard sprites, like the TPP run, the Red Blood patch has red blood. 

CREDITS:

Snakewood DX was partially based on Snakewood Zeta, by Eggnigma on Pok�community. This patch is included, as it appears to have rapidly become lost media. Snakewood DX was also based on the original Snakewood by the Cutlerine. Furthermore, additional credits are as follows:
Pokeemerald-Expansion and the team behind that, for gen 3 sprites for Zorua, Basculin-White, and Basculeg[i]on, as well as icon sprites for these pokemon, in addition to others such as Crustle and Dwebble.
Hex Maniac Advance and the team behind that, for tutorials and scripts followed in development.
https://github.com/ianhan/BitmapFonts, of which G_GOULS was used on the title screen.
The TPP staff and community, for assistance, suggestions... and many bug reports.
Sounds and Graphics from:
Gurren Lagann
Keitai Denjuu Telefang
B-52's
Chrono Trigger
Jirachi: Wishmaker
Zero-G Datafiles 1, 2 and 3
Zero-G Chemical Beats
and probably something else I'm forgetting.
As for any original sprites (CrazyMadio) or any new edits (Ghastlier line, new Stitcher, some backsprite edits) feel free to use without credit, but if you so desire you may credit myRattata. Additionally, bug reports can be directed into DMs on Discord for myrattata, or conversely the TwitchPlaysPok�mon Discord. For contact outside of Discord if necessary, the email froakies8@gmail.com should be used.

Thanks for your reading.
