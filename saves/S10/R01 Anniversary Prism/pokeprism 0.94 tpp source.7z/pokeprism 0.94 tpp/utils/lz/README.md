# lzcomp

LZ compressor for Pokémon Crystal. Implements a series of compression methods and picks the most optimal output
combining all of the attempts.

Compile it with `make`. Run it without arguments to see the help text.
